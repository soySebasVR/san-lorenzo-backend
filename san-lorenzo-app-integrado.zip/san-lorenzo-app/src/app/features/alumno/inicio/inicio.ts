import { Component, OnInit, signal } from '@angular/core';
import { PageTitle } from '../../../shared/components/page-title/page-title';
import { StatCard } from '../../../shared/components/stat-card/stat-card';
import { DashboardAlumnoService } from '../services/dashboard-alumno.service';
import { DashboardAlumnoResponse } from '../models/alumno.model';

@Component({
  selector: 'app-inicio',
  imports: [PageTitle, StatCard],
  templateUrl: './inicio.html',
  styleUrl: './inicio.scss',
})
export class Inicio implements OnInit {
  dashboard = signal<DashboardAlumnoResponse | null>(null);
  loading = signal(true);
  error = signal(false);

  constructor(private dashboardService: DashboardAlumnoService) {}

  ngOnInit(): void {
    this.dashboardService.getDashboard().subscribe({
      next: (data) => {
        this.dashboard.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set(true);
        this.loading.set(false);
      },
    });
  }
}
