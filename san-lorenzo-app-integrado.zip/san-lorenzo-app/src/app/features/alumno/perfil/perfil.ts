import { Component, OnInit, signal } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { PageTitle } from '../../../shared/components/page-title/page-title';
import { PerfilAlumnoService } from '../services/perfil-alumno.service';
import { PerfilAlumnoResponse } from '../models/alumno.model';

@Component({
  selector: 'app-perfil',
  imports: [PageTitle, ReactiveFormsModule],
  templateUrl: './perfil.html',
  styleUrl: './perfil.scss',
})
export class Perfil implements OnInit {
  loading = signal(true);
  error = signal(false);
  saving = signal(false);
  savedOk = signal(false);

  perfil = signal<PerfilAlumnoResponse | null>(null);

  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private perfilService: PerfilAlumnoService,
  ) {
    this.form = this.fb.group({
      nombreCompleto: ['', Validators.required],
      correoPersonal: ['', [Validators.required, Validators.email]],
      telefono: [''],
      notificacionesEmail: [true],
      notificacionesApp: [false],
    });
  }

  ngOnInit(): void {
    this.perfilService.getPerfil().subscribe({
      next: (data) => {
        this.perfil.set(data);
        this.form.patchValue({
          nombreCompleto: data.nombreCompleto,
          correoPersonal: data.correoPersonal,
          telefono: data.telefono ?? '',
          notificacionesEmail: data.notificacionesEmail,
          notificacionesApp: data.notificacionesApp,
        });
        this.loading.set(false);
      },
      error: () => {
        this.error.set(true);
        this.loading.set(false);
      },
    });
  }

  guardar(): void {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.saving.set(true);
    this.savedOk.set(false);

    this.perfilService.updatePerfil(this.form.value).subscribe({
      next: (data) => {
        this.perfil.set(data);
        this.saving.set(false);
        this.savedOk.set(true);
      },
      error: () => {
        this.saving.set(false);
        this.error.set(true);
      },
    });
  }
}
