import { Component, OnInit, computed, signal } from '@angular/core';
import { PageTitle } from '../../../shared/components/page-title/page-title';
import { TareasAlumnoService } from '../services/tareas-alumno.service';
import { Examen, Tarea } from '../models/alumno.model';

type Filtro = 'todas' | 'pendientes' | 'completadas';

@Component({
  selector: 'app-tareas',
  imports: [PageTitle],
  templateUrl: './tareas.html',
  styleUrl: './tareas.scss',
})
export class Tareas implements OnInit {
  tabActivo: 'tareas' | 'examenes' = 'tareas';
  filtro: Filtro = 'todas';

  loading = signal(true);
  error = signal(false);

  private todasLasTareas = signal<Tarea[]>([]);
  examenes = signal<Examen[]>([]);

  tareasFiltradas = computed(() => {
    const tareas = this.todasLasTareas();
    if (this.filtroSignal() === 'pendientes') return tareas.filter((t) => !t.completada);
    if (this.filtroSignal() === 'completadas') return tareas.filter((t) => t.completada);
    return tareas;
  });

  // Un signal espejo de `filtro` para poder usarlo dentro del computed de arriba
  // (los computed de Angular solo reaccionan a signals, no a propiedades planas).
  private filtroSignal = signal<Filtro>('todas');

  constructor(private tareasService: TareasAlumnoService) {}

  ngOnInit(): void {
    this.tareasService.getTareas().subscribe({
      next: (data) => {
        this.todasLasTareas.set(data.tareas);
        this.examenes.set(data.examenes);
        this.loading.set(false);
      },
      error: () => {
        this.error.set(true);
        this.loading.set(false);
      },
    });
  }

  setFiltro(f: Filtro): void {
    this.filtro = f;
    this.filtroSignal.set(f);
  }
}
