// ⚠️ CONTRATO PROPUESTO — el backend todavía NO expone estas rutas.
// Sigue el mismo estilo que ServerlessAPI.Dtos usa para el módulo docente
// (camelCase, mismo patrón de nombres) para que la integración sea inmediata
// en cuanto el equipo de backend cree el AlumnoController.

export interface CalificacionCurso {
  curso: string;
  icono: string;
  promedio: number;
  trimestre: string;
}

export interface TareaResumen {
  titulo: string;
  fechaEntrega: string; // ISO date
  icono: string;
}

export interface DashboardAlumnoResponse {
  promedioGeneral: number;
  asistenciaPorcentaje: number;
  tareasPendientes: number;
  totalCursos: number;
  calificaciones: CalificacionCurso[];
  tareasProximas: TareaResumen[];
}

export interface CursoCalificacion {
  curso: string;
  profesor: string;
  promedio: number; // 0-100
}

export interface CalificacionesAlumnoResponse {
  cursos: CursoCalificacion[];
}

export interface AsistenciaRegistro {
  curso: string;
  fecha: string; // ISO date
  presente: boolean;
}

export interface AsistenciaAlumnoResponse {
  totalInasistencias: number;
  historial: AsistenciaRegistro[];
}

export interface ClaseHorario {
  nombre: string;
  horaInicio: string; // "HH:mm"
  horaFin: string; // "HH:mm"
  diaSemana: number; // 0=Domingo ... 6=Sábado
  icono: string;
}

export interface HorarioAlumnoResponse {
  clases: ClaseHorario[];
}

export interface Tarea {
  id: number;
  titulo: string;
  fechaInicio: string;
  fechaEntrega: string;
  imagenUrl?: string;
  completada: boolean;
}

export interface Examen {
  id: number;
  titulo: string;
  fecha: string;
}

export interface TareasAlumnoResponse {
  tareas: Tarea[];
  examenes: Examen[];
}

export interface PerfilAlumnoResponse {
  estudianteId: number;
  nombreCompleto: string;
  gradoSeccion: string;
  correoPersonal: string;
  telefono: string | null;
  notificacionesEmail: boolean;
  notificacionesApp: boolean;
  region: string;
}

export interface UpdatePerfilAlumnoRequest {
  nombreCompleto: string;
  correoPersonal: string;
  telefono?: string | null;
  notificacionesEmail: boolean;
  notificacionesApp: boolean;
}
