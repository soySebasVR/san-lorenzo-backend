import { Component, OnInit, signal } from '@angular/core';
import { NgClass } from '@angular/common';
import { PageTitle } from '../../../shared/components/page-title/page-title';
import { HorariosAlumnoService } from '../services/horarios-alumno.service';
import { ClaseHorario } from '../models/alumno.model';

const DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

@Component({
  selector: 'app-horarios',
  imports: [PageTitle, NgClass],
  templateUrl: './horarios.html',
  styleUrl: './horarios.scss',
})
export class Horarios implements OnInit {
  loading = signal(true);
  error = signal(false);

  // Todas las clases de la semana, tal como las devuelve el backend.
  private todasLasClases = signal<ClaseHorario[]>([]);

  // Día actualmente seleccionado en el calendario (1-31, referido al mes que se muestra).
  diaActivo = 15;
  diaSeleccionado = 'Lunes, 15 de Abril';

  // Clases del día seleccionado (filtradas por diaSemana === new Date().getDay() por defecto).
  clasesDelDia = signal<ClaseHorario[]>([]);

  // Estructura del calendario (0 = celda vacía). Se mantiene estático por ahora;
  // no depende del backend.
  semanas: number[][] = [
    [0, 1, 2, 3, 4, 5, 6],
    [8, 9, 10, 11, 12, 13, 14],
    [15, 16, 17, 18, 19, 20, 21],
    [22, 23, 24, 25, 26, 27, 28],
    [29, 30, 0, 0, 0, 0, 0],
  ];

  constructor(private horariosService: HorariosAlumnoService) {}

  ngOnInit(): void {
    this.horariosService.getHorario().subscribe({
      next: (data) => {
        this.todasLasClases.set(data.clases);
        this.filtrarPorDiaSemana(new Date().getDay());
        this.loading.set(false);
      },
      error: () => {
        this.error.set(true);
        this.loading.set(false);
      },
    });
  }

  seleccionarDia(dia: number): void {
    this.diaActivo = dia;
    this.diaSeleccionado = 'Día ' + dia + ' de Abril';
    // TODO(backend): cuando el endpoint soporte filtrar por fecha exacta,
    // reemplazar esto por una llamada con esa fecha en vez de filtrar por
    // día de la semana en el cliente.
    this.filtrarPorDiaSemana(new Date().getDay());
  }

  private filtrarPorDiaSemana(diaSemana: number): void {
    this.clasesDelDia.set(this.todasLasClases().filter((c) => c.diaSemana === diaSemana));
  }
}
