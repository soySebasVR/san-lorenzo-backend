import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { CalificacionesAlumnoResponse } from '../models/alumno.model';

@Injectable({ providedIn: 'root' })
export class CalificacionesAlumnoService {
  private readonly base = `${environment.apiUrl}/alumno/notas`;

  constructor(private http: HttpClient) {}

  // TODO(backend): endpoint pendiente. Espejo de GET /docente/notas pero para Student
  // (filtrado por el propio studentId, sin necesitar query params de curso/sección).
  getCalificaciones(): Observable<CalificacionesAlumnoResponse> {
    return this.http.get<CalificacionesAlumnoResponse>(this.base);
  }
}
