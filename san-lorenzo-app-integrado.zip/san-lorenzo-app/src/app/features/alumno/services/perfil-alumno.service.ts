import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { PerfilAlumnoResponse, UpdatePerfilAlumnoRequest } from '../models/alumno.model';

@Injectable({ providedIn: 'root' })
export class PerfilAlumnoService {
  private readonly base = `${environment.apiUrl}/alumno/perfil`;

  constructor(private http: HttpClient) {}

  // TODO(backend): endpoint pendiente. Espejo de GET/PUT /docente/perfil pero para Student.
  getPerfil(): Observable<PerfilAlumnoResponse> {
    return this.http.get<PerfilAlumnoResponse>(this.base);
  }

  updatePerfil(request: UpdatePerfilAlumnoRequest): Observable<PerfilAlumnoResponse> {
    return this.http.put<PerfilAlumnoResponse>(this.base, request);
  }
}
