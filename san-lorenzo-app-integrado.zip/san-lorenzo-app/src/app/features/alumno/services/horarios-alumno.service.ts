import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { HorarioAlumnoResponse } from '../models/alumno.model';

@Injectable({ providedIn: 'root' })
export class HorariosAlumnoService {
  private readonly base = `${environment.apiUrl}/alumno/horarios`;

  constructor(private http: HttpClient) {}

  // TODO(backend): endpoint pendiente. Espejo de GET /docente/horarios pero para Student.
  getHorario(): Observable<HorarioAlumnoResponse> {
    return this.http.get<HorarioAlumnoResponse>(this.base);
  }
}
