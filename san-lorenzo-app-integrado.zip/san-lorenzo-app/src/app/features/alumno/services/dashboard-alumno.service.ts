import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { DashboardAlumnoResponse } from '../models/alumno.model';

@Injectable({ providedIn: 'root' })
export class DashboardAlumnoService {
  private readonly base = `${environment.apiUrl}/alumno/inicio`;

  constructor(private http: HttpClient) {}

  // TODO(backend): endpoint pendiente. Espejo de GET /docente/inicio pero para Student.
  getDashboard(): Observable<DashboardAlumnoResponse> {
    return this.http.get<DashboardAlumnoResponse>(this.base);
  }
}
