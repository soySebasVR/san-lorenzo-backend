import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { AsistenciaAlumnoResponse } from '../models/alumno.model';

@Injectable({ providedIn: 'root' })
export class AsistenciaAlumnoService {
  private readonly base = `${environment.apiUrl}/alumno/asistencia`;

  constructor(private http: HttpClient) {}

  // TODO(backend): endpoint pendiente.
  getAsistencia(): Observable<AsistenciaAlumnoResponse> {
    return this.http.get<AsistenciaAlumnoResponse>(this.base);
  }
}
