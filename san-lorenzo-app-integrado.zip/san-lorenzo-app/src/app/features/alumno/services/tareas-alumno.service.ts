import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../environments/environment';
import { TareasAlumnoResponse } from '../models/alumno.model';

@Injectable({ providedIn: 'root' })
export class TareasAlumnoService {
  private readonly base = `${environment.apiUrl}/alumno/tareas`;

  constructor(private http: HttpClient) {}

  // TODO(backend): endpoint pendiente. No tiene equivalente en el módulo docente todavía.
  getTareas(): Observable<TareasAlumnoResponse> {
    return this.http.get<TareasAlumnoResponse>(this.base);
  }
}
