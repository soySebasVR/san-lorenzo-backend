import { Component, OnInit, signal } from '@angular/core';
import { PageTitle } from '../../../shared/components/page-title/page-title';
import { AsistenciaAlumnoService } from '../services/asistencia-alumno.service';
import { AsistenciaAlumnoResponse } from '../models/alumno.model';

@Component({
  selector: 'app-asistencia',
  imports: [PageTitle],
  templateUrl: './asistencia.html',
  styleUrl: './asistencia.scss',
})
export class Asistencia implements OnInit {
  asistencia = signal<AsistenciaAlumnoResponse | null>(null);
  loading = signal(true);
  error = signal(false);

  constructor(private asistenciaService: AsistenciaAlumnoService) {}

  ngOnInit(): void {
    this.asistenciaService.getAsistencia().subscribe({
      next: (data) => {
        this.asistencia.set(data);
        this.loading.set(false);
      },
      error: () => {
        this.error.set(true);
        this.loading.set(false);
      },
    });
  }
}
