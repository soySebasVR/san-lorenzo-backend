import { Component, OnInit, signal } from '@angular/core';
import { PageTitle } from '../../../shared/components/page-title/page-title';
import { CalificacionesAlumnoService } from '../services/calificaciones-alumno.service';
import { CursoCalificacion } from '../models/alumno.model';

@Component({
  selector: 'app-calificaciones',
  imports: [PageTitle],
  templateUrl: './calificaciones.html',
  styleUrl: './calificaciones.scss',
})
export class Calificaciones implements OnInit {
  cursos = signal<CursoCalificacion[]>([]);
  loading = signal(true);
  error = signal(false);

  constructor(private calificacionesService: CalificacionesAlumnoService) {}

  ngOnInit(): void {
    this.calificacionesService.getCalificaciones().subscribe({
      next: (data) => {
        this.cursos.set(data.cursos);
        this.loading.set(false);
      },
      error: () => {
        this.error.set(true);
        this.loading.set(false);
      },
    });
  }
}
