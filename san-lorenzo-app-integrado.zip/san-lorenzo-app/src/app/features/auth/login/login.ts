import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Auth } from '../../../core/services/auth';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.scss',
})
export class Login {
  loginForm: FormGroup;
  errorMsg = '';
  loading = false;

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private auth: Auth,
  ) {
    this.loginForm = this.fb.group({
      usuario: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(8)]],
      remember: [false],
    });
  }

  get usuario() {
    return this.loginForm.get('usuario');
  }
  get password() {
    return this.loginForm.get('password');
  }

  login(): void {
    if (this.loginForm.invalid) {
      this.loginForm.markAllAsTouched();
      return;
    }

    this.errorMsg = '';
    this.loading = true;

    const { usuario, password } = this.loginForm.value;

    this.auth.login(usuario.trim(), password).subscribe({
      next: ({ user }) => {
        this.loading = false;
        this.router.navigate([this.routeForRole(user.role)]);
      },
      error: (err: HttpErrorResponse) => {
        this.loading = false;
        this.errorMsg =
          err.status === 401
            ? 'El correo o la contraseña no son correctos.'
            : 'No se pudo conectar con el servidor. Intenta de nuevo.';
      },
    });
  }

  private routeForRole(role: string): string {
    switch (role) {
      case 'Teacher':
        return '/docente';
      case 'Coordinator':
        return '/coordinador';
      case 'Student':
        return '/alumno';
      default:
        return '/login';
    }
  }
}
