import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Auth } from '../services/auth';

/**
 * Agrega el header "Authorization: Bearer <token>" a toda petición hacia
 * nuestra API. Las peticiones a otros dominios (ej. picsum.photos) no lo reciben.
 */
export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const auth = inject(Auth);
  const token = auth.getToken();

  if (!token || !req.url.startsWith(auth.apiUrl)) {
    return next(req);
  }

  const cloned = req.clone({
    setHeaders: { Authorization: `Bearer ${token}` },
  });

  return next(cloned);
};
