// Estos tipos reflejan EXACTAMENTE los DTOs de ServerlessAPI.Dtos.AuthDtos en el backend.
// Si el backend cambia esos records, hay que actualizar esto también.

export interface LoginRequest {
  email: string;
  password: string;
}

export interface CurrentUser {
  id: number;
  email: string;
  role: 'Teacher' | 'Coordinator' | 'Student' | string;
  fullName: string;
  teacherId: number | null;
  studentId: number | null;
}

export interface LoginResponse {
  token: string;
  expiresAt: string; // ISO date
  user: CurrentUser;
}
