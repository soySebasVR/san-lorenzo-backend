export const environment = {
  production: true,
  apiUrl: 'https://TU-API-ID.execute-api.TU-REGION.amazonaws.com/prod',
};
