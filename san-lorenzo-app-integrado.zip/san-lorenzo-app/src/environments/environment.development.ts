export const environment = {
  production: false,
  // URL local si corres `sam local start-api` (puerto 3000 por defecto),
  // o la URL de "ApiEndpoint" que imprime `sam deploy` una vez desplegado.
  apiUrl: 'http://localhost:3000',
};
